class script(object):


    START_MSG = """ <b>😍 Hey {}

💡 This is a Movies Series finder made for all types of Movies & Series sharing groups !

🔅 ᴍᴀɪɴᴛᴀɪɴᴇᴅ ʙʏ:- @BOTS_Infinity</b>"""


    HELP_MSG = """<u>💡 𝐇𝐞𝐥𝐩</u>
<i>
📌 Add Me To Any Group And Make Me Admin
📌 Add Me To Your Desired Channel
</i>

<b>🔰 𝐌𝐲 𝐂𝐨𝐦𝐦𝐚𝐧𝐝𝐬 (Works Only In Groups) :</b>
    👉 <code>/add chat_id</code>
                OR                  - To Connect A Group With A Channel (Bot Should Be Admin With Full Previlages In Both Group And Channel)
     <code>/add @Username</code>
     
    👉 <code>/del chat_id</code>
                OR                  - To disconnect A Group With A Channel
     <code>/del @Username</code>
     
    👉 <code>/delall</code>  - This Command Will Disconnect All Connected Channel With The Group And Deletes All Its File From DB
    
    👉 <code>/filterstats</code> -  Check connected channels and number of filters.
    

<b><a href="https://t.me/bots_infinity">©️ ɪɴғɪɴɪᴛʏ ʙᴏᴛs</a></b> """


    ABOUT_MSG = """
📕 𝐀𝐛𝐨𝐮𝐭 𝐌𝐞 ,
\n○ ᴍʏ ɴᴀᴍᴇ : <a href="https://t.me/BOTS_infinity">ɪɴꜰɪɴɪᴛʏ ꜰɪɴᴅᴇʀ</a>
○ ʟᴀɴɢᴜᴀɢᴇ : ᴘʏᴛʜᴏɴ 
○ ғʀᴀᴍᴇᴡᴏʀᴋ : ᴘʏʀᴏɢʀᴀᴍ 
○ sᴇʀᴠᴇʀ : ʜᴇʀᴏᴋᴜ 
○ ᴠᴇʀsɪᴏɴ : 1.0.0
○ sᴏᴜʀᴄᴇ ᴄᴏᴅᴇ : 🔐
○ ᴄʀᴇᴀᴛᴏʀ : <a href="https://t.me/dx_doc">ᴅᴏᴄ ᴅx</a>
<b><a href="https://t.me/bots_infinity">©️ ɪɴғɪɴɪᴛʏ ʙᴏᴛs</a></b>

"""
    
    TXT = """
🔮 𝗛𝗼𝘄 𝘁𝗼 𝗴𝗲𝘁 𝘆𝗼𝘂𝗿 𝗳𝗶𝗹𝗲𝘀
    
<b>1️⃣ ᴊᴏɪɴ ᴛʜᴇ ʙᴇʟᴏᴡ ᴄʜᴀɴɴᴇʟ ꜰɪʀꜱᴛ
 ʟɪɴᴋ  - https://t.me/joinchat/iTwvh9U7DH8wOWRl 
 
2️⃣ ʀᴇqᴜᴇꜱᴛ ʏᴏᴜʀ ꜱᴇʀɪᴇꜱ ᴀɢᴀɪɴ 
 
3️⃣ ᴄʟɪᴄᴋ ᴛʜᴇ ʙᴜᴛᴛᴏɴs ᴛᴏ ɢᴇᴛ ʏᴏᴜʀ sᴇʀɪᴇs ғɪʟᴇs

🛡 ᴄʟᴏꜱᴇ ᴛʜɪꜱ ᴍᴇꜱꜱᴀɢᴇ ᴀꜰᴛᴇʀ ʏᴏᴜ ʀᴇᴀᴅ ɪᴛ ❗️

<a href="https://t.me/bots_infinity">©️ ɪɴғɪɴɪᴛʏ ʙᴏᴛs</a></b>
 """
